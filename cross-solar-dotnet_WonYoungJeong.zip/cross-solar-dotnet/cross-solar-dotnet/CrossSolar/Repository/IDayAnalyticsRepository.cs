﻿using CrossSolar.Domain;

namespace CrossSolar.Repository
{
    public interface IDayAnalyticsRepository : IGenericRepository<OneDayElectricityModel>
    {
    }
}